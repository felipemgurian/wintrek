# PROJETO WINTREK

## FUNCIONALIDADES IMPLEMENTADAS:

### COMANDOS

**help            - Show help commands.**

(IMPLEMENTADO 100%)

**game            - Show game console.**

(IMPLEMENTADO 100%)

**warp            - Do a warp movement.**

(IMPLEMENTADO 100%)

**impulse         - Do an impulse movement.**

(IMPLEMENTADO 100%)

**increase_shield - Transfer energy to shields.**

(IMPLEMENTADO 100%)

**decrease_shield - Remove energy from shields.**

(IMPLEMENTADO 100%)

**phaser          - Attack enemy with phaser.**

(IMPLEMENTADO 100%)

**photon          - Attack enemy with photon.**

(IMPLEMENTADO 100%)

**scan            - Scan the current sector.**

(IMPLEMENTADO 100%)

### MOVIMENTAÇÃO NAVE INIMIGA

(IMPLEMENTADO 100%)

### ATAQUE NAVE INIMIGA

(IMPLEMENTADO 100%)

### CONTROLE DE ARMAS

(IMPLEMENTADO 100%)

### CONTROLE DE NAVEGAÇÃO

(IMPLEMENTADO 100%)

### CONTROLE DE ESCUDOS

(IMPLEMENTADO 100%)

### GERENCIAMENTO DE ENERGIA

(IMPLEMENTADO 100%)

### CONTROLE DE BORDO

IMPLEMENTADO SCAN DE QUADRANTE

### TEMPO NO JOGO

A cada segundo é somado 1 segundo no tempo do jogo, caso o jogador efetue algum tipo de movimentação, warp ou impulse, será somado 1 dia * distancia no tempo em segundos.

### RESTAURAÇÃO DA NAVA

Caso o a nave fique 1 casa ao lado da base espacial, a vida, os canhões fotonicos e a energia serão restauradas ao máximo

